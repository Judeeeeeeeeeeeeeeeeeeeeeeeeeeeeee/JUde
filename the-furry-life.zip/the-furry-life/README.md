# 🐾 The Furry Life

Your companion's wellness & vaccination calendar.

## Deploy to Vercel (step by step)

### Step 1 — Upload to GitHub
1. Go to github.com → sign in → click **+** → **New repository**
2. Name it `the-furry-life` → click **Create repository**
3. On the next page click **"uploading an existing file"**
4. Drag and drop ALL the files from this zip (keep folder structure)
5. Click **Commit changes**

### Step 2 — Deploy on Vercel
1. Go to vercel.com → sign in
2. Click **"Add New Project"**
3. Click **"Import"** next to your `the-furry-life` GitHub repo
4. Vercel auto-detects React — just click **Deploy**
5. Wait ~2 minutes → your site is live! 🎉

### Step 3 — Apply for Google AdSense
1. Go to adsense.google.com
2. Sign in with Gmail → click **Get Started**
3. Enter your new Vercel URL (e.g. the-furry-life.vercel.app)
4. Wait for approval (1–14 days)
5. Once approved, paste your ad code and start earning 💰

## Tech Stack
- React 18
- No backend required
- Data stored in browser localStorage

## Features
- 12 animal types, 1400+ breeds
- Vaccine & care reminders
- 2-year health schedule
- Free tier: 4 pets | Premium: unlimited
- Sign in / Register system
