import { useState, useEffect } from "react";

// ─── Animal Types ────────────────────────────────────────────────────────────
const ANIMAL_TYPES = [
  { id: "cat",        label: "Cat",         emoji: "🐱" },
  { id: "dog",        label: "Dog",         emoji: "🐶" },
  { id: "rabbit",     label: "Rabbit",      emoji: "🐰" },
  { id: "bird",       label: "Bird",        emoji: "🦜" },
  { id: "hamster",    label: "Hamster",     emoji: "🐹" },
  { id: "guinea_pig", label: "Guinea Pig",  emoji: "🐾" },
  { id: "fish",       label: "Fish",        emoji: "🐟" },
  { id: "turtle",     label: "Turtle",      emoji: "🐢" },
  { id: "horse",      label: "Horse",       emoji: "🐴" },
  { id: "ferret",     label: "Ferret",      emoji: "🦡" },
  { id: "snake",      label: "Snake",       emoji: "🐍" },
  { id: "lizard",     label: "Lizard",      emoji: "🦎" },
];

// ─── Breeds by type ───────────────────────────────────────────────────────────
const BREEDS_BY_TYPE = {
  cat: [
    // A
    "Abyssinian","American Bobtail","American Curl","American Ringtail","American Shorthair",
    "American Wirehair","Anatoli","Arabian Mau","Asian","Asian Semi-longhair",
    "Australian Mist",
    // B
    "Balinese","Bambino","Bengal","Birman","Bombay","Brazilian Shorthair",
    "British Longhair","British Shorthair","Burmese","Burmilla",
    // C
    "California Spangled","Chantilly-Tiffany","Chartreux","Chausie","Cheetoh",
    "Colorpoint Shorthair","Cornish Rex","Cymric","Cyprus",
    // D
    "Desert Lynx","Devon Rex","Donskoy (Don Sphynx)","Dragon Li (Li Hua)",
    "Dwelf",
    // E
    "Egyptian Mau","European Shorthair","Exotic Shorthair",
    // F
    "Foldex",
    // G
    "German Rex","Havana Brown","Highlander","Himalayan",
    // H-J
    "Japanese Bobtail","Javanese",
    // K
    "Kanaani","Khao Manee","Kinkalow","Korat","Korean Bobtail","Kurilian Bobtail",
    // L
    "LaPerm","Lykoi",
    // M
    "Maine Coon","Mandalay","Manx","Minskin","Minuet (Napoleon)","Munchkin",
    // N
    "Nebelung","Norwegian Forest Cat",
    // O
    "Ocicat","Ojos Azules","Oregon Rex","Oriental Longhair","Oriental Shorthair",
    // P
    "Persian","Peterbald","Pixiebob",
    // R
    "Ragamuffin","Ragdoll","Russian Blue","Russian White","Russian Black",
    // S
    "Sam Sawet","Savannah","Scottish Fold","Scottish Straight","Selkirk Rex",
    "Serengeti","Serrade Petit","Siamese","Siberian","Singapura","Snowshoe",
    "Sokoke","Somali","Sphynx","Sterling",
    // T
    "Tennessee Rex","Thai","Thai Lilac","Tiffanie","Tonkinese","Toyger",
    "Turkish Angora","Turkish Van","Turkish Vankedisi",
    // U-Y
    "Ukrainian Levkoy","York Chocolate",
    // Mixed
    "Domestic Shorthair (Mixed)","Domestic Longhair (Mixed)",
  ],
  dog: [
    // A
    "Affenpinscher","Afghan Hound","Airedale Terrier","Akbash","Akita",
    "Alaskan Klee Kai","Alaskan Malamute","Alpine Dachsbracke","American Bulldog",
    "American English Coonhound","American Eskimo Dog","American Foxhound",
    "American Hairless Terrier","American Leopard Hound","American Pitbull Terrier",
    "American Staffordshire Terrier","American Water Spaniel","Anatolian Shepherd",
    "Appenzeller Sennenhund","Argentine Dogo","Ariege Pointer","Ariegeois",
    "Armenian Gampr","Artois Hound","Australian Cattle Dog","Australian Kelpie",
    "Australian Shepherd","Australian Silky Terrier","Australian Stumpy Tail Cattle Dog",
    "Australian Terrier","Austrian Black and Tan Hound","Austrian Pinscher",
    "Azawakh",
    // B
    "Barbet","Basenji","Basset Artesien Normand","Basset Bleu de Gascogne",
    "Basset Fauve de Bretagne","Basset Griffon Vendeen (Grand)","Basset Griffon Vendeen (Petit)",
    "Basset Hound","Bavarian Mountain Scent Hound","Beagle","Beagle-Harrier",
    "Bearded Collie","Beauceron","Bedlington Terrier","Belgian Griffon","Belgian Laekenois",
    "Belgian Malinois","Belgian Sheepdog (Groenendael)","Belgian Tervuren",
    "Bergamasco Sheepdog","Berger Blanc Suisse","Berger Picard","Bernese Mountain Dog",
    "Bichon Frise","Billy","Black and Tan Coonhound","Black and Tan Virginia Foxhound",
    "Black Norwegian Elkhound","Black Russian Terrier","Bloodhound","Blue Lacy",
    "Blue Picardy Spaniel","Bluetick Coonhound","Boerboel","Bohemian Shepherd",
    "Bolognese","Border Collie","Border Terrier","Borzoi","Boston Terrier",
    "Bouvier des Ardennes","Bouvier des Flandres","Boxer","Boykin Spaniel",
    "Bracco Italiano","Braque d'Auvergne","Braque du Bourbonnais","Braque Francais",
    "Braque Saint-Germain","Briard","Briquet Griffon Vendeen","Brittany","Broholmer",
    "Bruno Jura Hound","Bull Arab","Bull Terrier","Bulldog (English)","Bullmastiff",
    // C
    "Ca de Bou","Cairn Terrier","Canaan Dog","Canadian Eskimo Dog","Cane Corso",
    "Cardigan Welsh Corgi","Carolina Dog","Carpathian Shepherd","Catalan Sheepdog",
    "Caucasian Shepherd Dog","Cavalier King Charles Spaniel","Central Asian Shepherd",
    "Cesky Fousek","Cesky Terrier","Chesapeake Bay Retriever","Chihuahua",
    "Chinese Crested","Chinese Shar-Pei","Chinook","Chow Chow","Cirneco dell'Etna",
    "Clumber Spaniel","Cocker Spaniel (American)","Cocker Spaniel (English)",
    "Collie (Rough)","Collie (Smooth)","Coton de Tulear","Croatian Sheepdog",
    "Curly-Coated Retriever",
    // D
    "Dachshund (Miniature)","Dachshund (Standard)","Dachshund (Wire-haired)",
    "Dalmatian","Dandie Dinmont Terrier","Danish Swedish Farmdog","Dingo",
    "Doberman Pinscher","Dogo Argentino","Dogue de Bordeaux","Drentsche Patrijshond",
    "Drever","Dunker","Dutch Shepherd","Dutch Smoushond",
    // E
    "East Siberian Laika","English Setter","English Springer Spaniel","English Toy Spaniel",
    "English Toy Terrier","Entlebucher Mountain Dog","Estrela Mountain Dog",
    "Eurasier",
    // F
    "Field Spaniel","Fila Brasileiro","Finnish Hound","Finnish Lapphund","Finnish Spitz",
    "Flat-Coated Retriever","Fox Terrier (Smooth)","Fox Terrier (Wire)","Foxhound (American)",
    "Foxhound (English)","French Bulldog","French Spaniel",
    // G
    "German Longhaired Pointer","German Pinscher","German Shepherd Dog",
    "German Shorthaired Pointer","German Spitz (Giant)","German Spitz (Mittel)",
    "German Wirehaired Pointer","Giant Schnauzer","Glen of Imaal Terrier",
    "Golden Retriever","Gordon Setter","Grand Anglo-Francais Blanc et Noir",
    "Grand Anglo-Francais Blanc et Orange","Grand Anglo-Francais Tricolore",
    "Grand Basset Griffon Vendeen","Grand Bleu de Gascogne","Grand Griffon Vendeen",
    "Great Dane","Great Pyrenees","Greater Swiss Mountain Dog","Greek Harehound",
    "Greenland Dog","Greyhound","Griffon Belge","Griffon Bruxellois","Griffon Fauve de Bretagne",
    // H
    "Hamiltonstovare","Hanoverian Scenthound","Harrier","Havanese","Hellenikos Ichnilatis",
    "Himalayan Sheepdog","Hokkaido","Hovawart","Hungarian Greyhound",
    // I
    "Ibizan Hound","Icelandic Sheepdog","Irish Red and White Setter","Irish Setter",
    "Irish Terrier","Irish Water Spaniel","Irish Wolfhound","Istrian Coarse-haired Hound",
    "Istrian Short-haired Hound","Italian Greyhound","Italian Spinone",
    // J
    "Jack Russell Terrier","Japanese Chin","Japanese Spitz","Japanese Terrier",
    "Jindo","Jonangi",
    // K
    "Kai Ken","Kangal Shepherd","Karelian Bear Dog","Keeshond","Kerry Beagle",
    "Kerry Blue Terrier","King Charles Spaniel","Kishu Ken","Komondor","Kooikerhondje",
    "Koolie","Korean Jindo","Kraski Ovcar","Kunming Wolfdog","Kuvasz",
    // L
    "Labrador Retriever","Lagotto Romagnolo","Lancashire Heeler","Landseer",
    "Leonberger","Lhasa Apso","Longdog","Louisiana Catahoula Leopard","Lowchen",
    // M
    "Maltese","Manchester Terrier","Maremma Sheepdog","Mastiff","McNab Shepherd",
    "Miniature Bull Terrier","Miniature Pinscher","Miniature Schnauzer",
    "Mioritic Shepherd","Mudi","Mudhol Hound",
    // N
    "Neapolitan Mastiff","Nederlandse Kooikerhondje","New Guinea Singing Dog",
    "Newfoundland","Norfolk Terrier","Norrbottenspets","Norwegian Buhund",
    "Norwegian Elkhound","Norwegian Lundehund","Norwich Terrier","Nova Scotia Duck Tolling Retriever",
    // O
    "Old Danish Pointer","Old English Sheepdog","Otterhound","Owczarek Podhalanski",
    // P
    "Papillon","Parson Russell Terrier","Pekingese","Pembroke Welsh Corgi",
    "Perro de Presa Canario","Peruvian Inca Orchid","Petit Basset Griffon Vendeen",
    "Pharaoh Hound","Picardy Spaniel","Plott Hound","Pointer","Polish Greyhound",
    "Polish Lowland Sheepdog","Polish Tatra Sheepdog","Pomeranian","Pont-Audemer Spaniel",
    "Poodle (Miniature)","Poodle (Standard)","Poodle (Toy)","Porcelaine","Portuguese Pointer",
    "Portuguese Sheepdog","Portuguese Water Dog","Posavac Hound","Pug","Puli","Pumi",
    "Pyrenean Mastiff","Pyrenean Shepherd",
    // R
    "Rafeiro do Alentejo","Rat Terrier","Redbone Coonhound","Rhodesian Ridgeback",
    "Romanian Mioritic Shepherd","Rottweiler","Rough Collie","Russian Toy",
    "Russian-European Laika",
    // S
    "Saint Bernard","Saluki","Samoyed","Sarplaninac","Schapendoes","Schillerstovare",
    "Schipperke","Scottish Deerhound","Scottish Terrier","Sealyham Terrier",
    "Segugio Italiano","Shetland Sheepdog","Shiba Inu","Shih Tzu","Shikoku",
    "Siberian Husky","Silky Terrier","Skye Terrier","Sloughi","Slovak Cuvac",
    "Slovensky Kopov","Slovensky Rough-haired Pointer","Small Munsterlander",
    "Smooth Collie","Smooth Fox Terrier","Soft Coated Wheaten Terrier",
    "South Russian Ovcharka","Spanish Greyhound (Galgo Espanol)","Spanish Mastiff",
    "Spanish Water Dog","Spinone Italiano","Sporting Lucas Terrier","St. Bernard",
    "Stabyhoun","Staffordshire Bull Terrier","Standard Schnauzer","Sussex Spaniel",
    "Swedish Lapphund","Swedish Vallhund",
    // T
    "Taigan","Teddy Roosevelt Terrier","Thai Bangkaew Dog","Thai Ridgeback",
    "Tibetan Mastiff","Tibetan Spaniel","Tibetan Terrier","Tornjak","Tosa Inu",
    "Treeing Tennessee Brindle","Treeing Walker Coonhound",
    // V
    "Vizsla","Volpino Italiano",
    // W
    "Weimaraner","Welsh Sheepdog","Welsh Springer Spaniel","Welsh Terrier",
    "West Highland White Terrier","West Siberian Laika","Whippet","White Swiss Shepherd",
    "Wire Fox Terrier","Wirehaired Pointing Griffon","Wirehaired Vizsla",
    // X-Z
    "Xoloitzcuintli","Yorkshire Terrier",
    // Mixed
    "Mixed Breed","Mutt",
  ],
  rabbit: [
    "American","American Chinchilla","American Fuzzy Lop","American Sable",
    "Angora — English","Angora — French","Angora — Giant","Angora — Satin",
    "Belgian Hare","Beveren","Blanc de Hotot","Britannia Petite",
    "Californian","Checkered Giant","Cinnamon","Crème d'Argent",
    "Dutch","Dwarf Hotot","English Lop","English Spot",
    "Flemish Giant","Florida White","French Lop",
    "Giant Chinchilla","Harlequin","Havana","Himalayan","Holland Lop",
    "Jersey Wooly",
    "Lilac","Lionhead","Mini Lop","Mini Rex","Mini Satin",
    "Netherland Dwarf","New Zealand",
    "Palomino","Perlfee","Polish",
    "Rex","Rhinelander",
    "Satin","Silver","Silver Fox","Silver Marten","Standard Chinchilla",
    "Tan","Thrianta","Velveteen Lop",
    "Mixed Breed",
  ],
  bird: [
    // Parrots & Parakeets
    "African Grey Parrot (Congo)","African Grey Parrot (Timneh)",
    "Amazon Parrot — Blue-fronted","Amazon Parrot — Double Yellow-headed",
    "Amazon Parrot — Lilac-crowned","Amazon Parrot — Orange-winged",
    "Amazon Parrot — Yellow-crowned","Amazon Parrot — Yellow-naped",
    "Bourke's Parakeet","Budgerigar (Budgie)",
    "Caique — Black-headed","Caique — White-bellied",
    "Cape Parrot","Cockatiel","Cockatoo — Black","Cockatoo — Galah (Rose-breasted)",
    "Cockatoo — Major Mitchell's","Cockatoo — Moluccan (Salmon-crested)",
    "Cockatoo — Sulphur-crested","Cockatoo — Umbrella","Cockatoo — Yellow-tailed Black",
    "Conure — Blue-crowned","Conure — Cherry-headed","Conure — Dusky-headed",
    "Conure — Golden","Conure — Green-cheeked","Conure — Jenday",
    "Conure — Mitred","Conure — Nanday","Conure — Painted","Conure — Patagonian",
    "Conure — Peach-fronted","Conure — Sun","Conure — White-eyed",
    "Derbyan Parakeet","Eclectus Parrot","Electus Parrot","Elegant Parrot",
    "Fig Parrot","Golden Parakeet","Hawk-headed (Red-fan) Parrot",
    "Indian Ringneck Parakeet","Jardine's Parrot","Kakariki (Red-fronted)",
    "Kakariki (Yellow-fronted)","Lineolated Parakeet","Lorikeet — Rainbow",
    "Lorikeet — Scaly-breasted","Lorikeet — Varied","Lory — Black-capped",
    "Lory — Chattering","Lory — Dusky","Lory — Purple-naped",
    "Lovebird — Black-cheeked","Lovebird — Black-collared","Lovebird — Black-winged",
    "Lovebird — Fischer's","Lovebird — Lilian's (Nyasa)","Lovebird — Masked",
    "Lovebird — Peach-faced","Lovebird — Red-faced","Lovebird — Rosy-faced",
    "Lovebird — Swindern's","Macaw — Blue & Gold (Yellow)","Macaw — Blue-throated",
    "Macaw — Buffon's (Great Green)","Macaw — Hahn's (Red-shouldered)",
    "Macaw — Hyacinth","Macaw — Illiger's (Blue-winged)","Macaw — Military",
    "Macaw — Red-bellied","Macaw — Red-fronted","Macaw — Scarlet",
    "Macaw — Severe (Chestnut-fronted)","Macaw — Spix's","Macaw — Yellow-collared",
    "Meyer's Parrot","Monk (Quaker) Parakeet","Moustached Parakeet",
    "Parakeet — Alexandrine","Parakeet — Barraband's","Parakeet — Plum-headed",
    "Parakeet — Rock","Parakeet — Superb","Parrotlet — Blue-winged",
    "Parrotlet — Green-rumped","Parrotlet — Mexican (Turquoise-rumped)",
    "Parrotlet — Pacific","Parrotlet — Spectacled","Pionus — Blue-headed",
    "Pionus — Bronze-winged","Pionus — Dusky","Pionus — Maximilian's (Scaly-headed)",
    "Pionus — White-capped","Poicephalus — Brown-headed","Poicephalus — Cape",
    "Poicephalus — Jardine's","Poicephalus — Red-bellied","Poicephalus — Ruppell's",
    "Poicephalus — Senegal","Princess of Wales Parakeet","Regent Parrot",
    "Rosella — Crimson","Rosella — Eastern","Rosella — Green","Rosella — Western",
    "Swift (Horned) Parakeet","Vasa Parrot",
    // Finches & Canaries
    "Canary — Border Fancy","Canary — Frill","Canary — Gloster","Canary — Lizard",
    "Canary — Norwich","Canary — Red Factor","Canary — Roller","Canary — Yorkshire",
    "Finch — Black-throated","Finch — Double Bar","Finch — Gouldian",
    "Finch — Long-tailed","Finch — Masked","Finch — Owl","Finch — Painted",
    "Finch — Plum-headed","Finch — Red-browed","Finch — Society (Bengalese)",
    "Finch — Star","Finch — Strawberry (Red Avadavat)","Finch — Zebra",
    "Java Sparrow","Munias & Mannikins — Chestnut","Munias & Mannikins — Spice",
    "Munias & Mannikins — White-headed","Waxbill — Common","Waxbill — Orange-cheeked",
    "Waxbill — Sydney (Red-eared)","Waxbill — Violet-eared",
    // Softbills & Others
    "Dove — Diamond","Dove — Ringneck","Dove — White",
    "Hill Mynah (Common Mynah)","Laughing Thrush","Pekin Robin (Red-billed Leiothrix)",
    "Shama","Starling — Bali (Rothschild's)","Starling — Purple Glossy",
    "Starling — Superb","Toucan — Emerald","Toucan — Keel-billed","Toucan — Toco",
    "Toucanet — Collared Aracari","Toucanet — Spot-billed",
    "Weaver — Napoleon","Weaver — Village",
  ],
  hamster: [
    "Campbell's Dwarf (Campbell's Russian)","Chinese Hamster",
    "Djungarian Dwarf (Siberian)","European Hamster (Black-bellied)","Roborovski Dwarf",
    "Russian Winter White Dwarf","Syrian — Banded","Syrian — Black Bear",
    "Syrian — Dalmatian","Syrian — Golden (Standard)","Syrian — Long-haired (Teddy Bear)",
    "Syrian — Rex","Syrian — Satin","Syrian — Short-haired",
    "Syrian — Tortoiseshell & White","Turkish Hamster","Mixed",
  ],
  guinea_pig: [
    "Abyssinian","Abyssinian Satin","Alpaca","American (English Shorthair)",
    "American Satin","Baldwin","Coronet","Coronet Satin","Lunkarya","Merino",
    "Merino Satin","Peruvian","Peruvian Satin","Rex","Ridgeback",
    "Silkie (Sheltie)","Silkie Satin","Skinny","Teddy","Teddy Satin",
    "Texel","Texel Satin","White Crested","Mixed Breed",
  ],
  fish: [
    // Tropical Freshwater
    "African Butterfly Fish","African Cichlid — Auratus","African Cichlid — Blue Peacock",
    "African Cichlid — Electric Blue Hap","African Cichlid — Frontosa","African Cichlid — Kenyi",
    "African Cichlid — Lemon","African Cichlid — Maingano","African Cichlid — Rusty",
    "African Cichlid — Taiwan Reef","African Cichlid — Yellow Lab",
    "Angelfish — Altum","Angelfish — Common (Freshwater)","Arowana — Asian (Silver)",
    "Arowana — Australian (Jardini)","Arowana — Black","Arowana — Green",
    "Bala Shark","Banded Leporinus","Barb — Cherry","Barb — Gold","Barb — Rosy",
    "Barb — Spanner","Barb — Tiger","Barb — Tinfoil","Barb — Two-spot",
    "Betta (Siamese Fighting Fish) — Crowntail","Betta — Delta","Betta — Double Tail",
    "Betta — Halfmoon","Betta — King","Betta — Plakat","Betta — Rosetail",
    "Betta — Veil Tail","Black Ghost Knifefish","Black Molly","Black Neon Tetra",
    "Black Skirt Tetra","Blind Cave Tetra","Blood Parrot Cichlid","Bloodfin Tetra",
    "Blue Acara","Blue Gourami","Boesemani Rainbowfish","Bristlenose Pleco",
    "Bronze Corydoras","Buenos Aires Tetra","Cardinal Tetra",
    "Catfish — Pictus","Catfish — Striped Raphael","Catfish — Synodontis",
    "Cave Tetra","Celestial Pearl Danio","Chocolate Gourami","Clown Loach",
    "Clown Pleco","Cobalt Blue Zebra Cichlid","Congo Tetra","Convict Cichlid",
    "Corydoras — Bronze","Corydoras — Emerald","Corydoras — Julii","Corydoras — Panda",
    "Corydoras — Peppered","Corydoras — Pygmy","Corydoras — Sterbai",
    "Danio — Giant","Danio — Leopard","Danio — Pearl","Danio — Zebra",
    "Discus — Blue Diamond","Discus — Checkerboard","Discus — Heckel",
    "Discus — Leopard","Discus — Marlboro Red","Discus — Pigeon Blood",
    "Discus — Red Map","Discus — Turquoise","Dwarf Cichlid — Agassizi",
    "Dwarf Cichlid — Apistogramma","Dwarf Cichlid — Ram (German Blue Ram)",
    "Dwarf Gourami","Electric Blue Acara","Electric Blue Jack Dempsey",
    "Electric Eel","Elephant Nose Fish","Emperor Tetra","Endler's Livebearer",
    "Fahaka Pufferfish","Fire Eel","Flowerhorn Cichlid","Frontosa Cichlid",
    "Ghost Catfish","Giant Gourami","Glowlight Tetra","Gold Nugget Pleco",
    "Goldfish — Black Moor","Goldfish — Bubble Eye","Goldfish — Butterfly Tail",
    "Goldfish — Celestial Eye","Goldfish — Common","Goldfish — Comet",
    "Goldfish — Fantail","Goldfish — Lionhead","Goldfish — Oranda",
    "Goldfish — Pearlscale","Goldfish — Pompom","Goldfish — Ranchu",
    "Goldfish — Ryukin","Goldfish — Shubunkin","Goldfish — Telescope",
    "Goldfish — Veiltail","Gouramis — Kissing","Gouramis — Moonlight",
    "Gouramis — Pearl","Gouramis — Thick-lipped","Green Swordtail",
    "Green Terror Cichlid","Guppy — Endler","Guppy — Fancy",
    "Hatchetfish — Common","Hatchetfish — Marbled","Hatchetfish — Silver",
    "Hoplo Catfish","Jack Dempsey Cichlid","Jaguar Cichlid","Koi — Butterfly",
    "Koi — Chagoi","Koi — Kohaku","Koi — Ogon","Koi — Sanke","Koi — Showa",
    "Koi — Tancho","Kribensis Cichlid","Kuhlii Loach","Lemon Tetra",
    "Leopard Ctenopoma","Loach — Clown","Loach — Dojo","Loach — Hillstream",
    "Loach — Kuhli","Loach — Skunk","Loach — Weather",
    "Malawi Eye-biter","Midnight Molly","Molly — Black","Molly — Gold Dust",
    "Molly — Sailfin","Molly — White","Mosquito Fish","Neon Tetra",
    "Odessa Barb","Oscar — Albino","Oscar — Red","Oscar — Tiger",
    "Otocinclus Catfish","Pakoo (Pacú)","Parrot Fish","Pearl Danio","Pearl Gourami",
    "Penguin Tetra","Piranha — Red-bellied","Platy — Blue","Platy — Mickey Mouse",
    "Platy — Red","Platy — Sunburst","Platy — Wagtail","Platy — Yellow",
    "Pleco — Bristlenose","Pleco — Clown","Pleco — Common","Pleco — Sailfin",
    "Pleco — Zebra","Puffer — Amazon","Puffer — Dwarf","Puffer — Figure Eight",
    "Rainbow Fish — Australian","Rainbow Fish — Boesemani","Rainbow Fish — Dwarf Neon",
    "Rainbow Fish — Melanotaenia","Rainbow Fish — Threadfin",
    "Ram Cichlid — Bolivian","Ram Cichlid — German Blue","Rasbora — Brilliant",
    "Rasbora — Chili","Rasbora — Dwarf","Rasbora — Harlequin","Rasbora — Lambchop",
    "Red-tailed Black Shark","Redtail Catfish","Rope Fish (Reed Fish)",
    "Rummy Nose Tetra","Salvini Cichlid","Serpae Tetra","Silver Dollar",
    "Silver Hatchetfish","Swordtail — Green","Swordtail — Hi-fin",
    "Swordtail — Marigold","Swordtail — Red Velvet","Tetra — Black Phantom",
    "Tetra — Bleeding Heart","Tetra — Glowlight","Tetra — Green Neon",
    "Tiger Barb","Upside-down Catfish","White Cloud Mountain Minnow",
    "Worm Catfish (Stiphodon)","Yellow Lab Cichlid",
    // Marine / Saltwater
    "Basslet — Royal Gramma","Basslet — Swales","Blenny — Bicolor",
    "Blenny — Lawnmower","Blenny — Midas","Blenny — Tailspot",
    "Boxfish — Yellow","Butterflyfish — Copperband","Butterflyfish — Raccoon",
    "Cardinal Fish — Banggai","Cardinal Fish — Pajama",
    "Chromis — Blue-green","Clownfish — Common (Ocellaris)","Clownfish — Maroon",
    "Clownfish — Percula","Clownfish — Tomato","Damselfish — Blue Devil",
    "Damselfish — Yellowtail Blue","Dragonet — Mandarinfish","Dottyback — Orchid",
    "Filefish — Matted","Firefish — Common","Firefish — Purple","Foxface Rabbitfish",
    "Goby — Clown","Goby — Neon","Goby — Watchman","Goby — Yellow",
    "Hawkfish — Arc-eye","Hawkfish — Flame","Jawfish — Blue-spot","Jawfish — Yellow-head",
    "Lionfish — Common (Volitans)","Lionfish — Dwarf (Fuzzy)","Mandarin Dragonet",
    "Moorish Idol","Pufferfish — Dog Face","Pufferfish — Stars & Stripes",
    "Sea Horse — Dwarf","Sea Horse — Lined","Surgeonfish — Blue Tang",
    "Surgeonfish — Orange Shoulder","Triggerfish — Clown","Triggerfish — Niger",
    "Wrasse — Banana","Wrasse — Cleaner","Wrasse — Dragon","Wrasse — Fairy",
    "Wrasse — Six-line","Wrasse — Yellow Coris",
  ],
  turtle: [
    // Aquatic & Semi-aquatic Turtles
    "Alligator Snapping Turtle","Asian Leaf Turtle","Asian Yellow Pond Turtle",
    "Barbour's Map Turtle","Black-breasted Leaf Turtle","Blanding's Turtle",
    "Box Turtle — Desert","Box Turtle — Eastern","Box Turtle — Gulf Coast",
    "Box Turtle — Ornate","Box Turtle — Three-toed","Box Turtle — Western",
    "Chinese Softshell Turtle","Chicken Turtle","Common Map Turtle",
    "Common Musk Turtle (Stinkpot)","Common Snapping Turtle",
    "Diamondback Terrapin","Earless River Turtle","Eastern Box Turtle",
    "European Pond Turtle","False Map Turtle","Florida Box Turtle",
    "Florida Cooter","Florida Redbelly Cooter","Florida Softshell Turtle",
    "Indian Roofed Turtle","Indian Star Tortoise","Japanese Pond Turtle",
    "Malaysian Giant Turtle","Mississippi Map Turtle","Mud Turtle — Eastern",
    "Mud Turtle — Striped","Murray River Turtle","Musk Turtle — Flattened",
    "Musk Turtle — Loggerhead","Musk Turtle — Razorback","Musk Turtle — Stripe-necked",
    "Northern Map Turtle","Ouachita Map Turtle","Painted Turtle — Eastern",
    "Painted Turtle — Midland","Painted Turtle — Southern","Painted Turtle — Western",
    "Pond Slider","Red-bellied Cooter","Red-eared Slider","River Cooter",
    "Side-necked Turtle — African","Side-necked Turtle — South American Mata Mata",
    "Smooth Softshell Turtle","Spiny Softshell Turtle","Spotted Turtle",
    "Western Pond Turtle","Wood Turtle","Yellow-bellied Slider","Yellow-blotched Map Turtle",
    // Tortoises
    "African Helmeted Tortoise","African Pancake Tortoise","African Spurred Tortoise (Sulcata)",
    "Aldabra Tortoise","Burmese Star Tortoise","Cape Tortoise (Padloper)",
    "Chaco Tortoise","Desert Tortoise","Egyptian Tortoise","Elongated Tortoise",
    "Forsten's Tortoise","Galapagos Tortoise","Geometric Tortoise",
    "Giant Tortoises (Geochelone)","Greek (Spur-thighed) Tortoise",
    "Hermann's Tortoise — Eastern","Hermann's Tortoise — Western",
    "Hingeback Tortoise — Bell's","Hingeback Tortoise — Home's",
    "Horsfield's (Russian) Tortoise","Indian Star Tortoise","Kleinmann's Tortoise",
    "Leopard Tortoise","Marginated Tortoise","Mediterranean Spur-thighed",
    "Mojave Desert Tortoise","Radiated Tortoise","Red-footed Tortoise",
    "Sonoran Desert Tortoise","Spider Tortoise","Sulcata Tortoise","Texas Tortoise",
    "Travancore Tortoise","Yellow-footed Tortoise",
  ],
  horse: [
    // Light Breeds
    "Akhal-Teke","American Paint Horse","American Quarter Horse","American Saddlebred",
    "American Standardbred","Andalusian (PRE)","Anglo-Arabian","Appaloosa",
    "Arabian","Azteca","Barb","Bashkir Curly","Belgian Warmblood",
    "Brandenburg","Budyonny","Camargue","Cleveland Bay","Colorado Ranger",
    "Criollo","Czech Warmblood","Danish Warmblood","Dutch Warmblood (KWPN)",
    "Friesian","Hanoverian","Holsteiner","Hungarian Warmblood",
    "Icelandic Horse","Irish Draught","Irish Sport Horse","Kentucky Mountain Saddle Horse",
    "Knabstrupper","Lipizzaner","Lusitano","Lusitano (Alter Real)",
    "Mangalarga Marchador","Marwari","Missouri Fox Trotter","Morgan",
    "Mustang","National Show Horse","Nokota","Oldenburg","Orlov Trotter",
    "Paint Horse","Palomino","Paso Fino","Peruvian Paso",
    "Pinto","Polish Warmblood","Przewalski's Horse","Quarter Pony",
    "Rocky Mountain Horse","Russian Trotter","Saddlebred","Selle Français",
    "Shagya Arabian","Spanish Mustang","Standardbred","Swedish Warmblood",
    "Tennessee Walking Horse","Thoroughbred","Trakehner","Ukrainian Riding Horse",
    "Warmblood — Generic","Westphalian","Zweibrücker",
    // Draft Breeds
    "Belgian Draft (Brabant)","Black Forest Horse","Boulonnais","Breton",
    "Clydesdale","Comtois","Fjord (Norwegian Fjord)","Friesian (Draft)",
    "Gypsy Vanner (Irish Cob)","Haflinger","Italian Heavy Draft",
    "Lithuanian Heavy Draft","Murakoz","Noriker","North Swedish Horse",
    "Percheron","Rhenish-German Draft","Russian Heavy Draft","Schleswig",
    "Shire","Spotted Draft","Suffolk Punch","Vladimir Heavy Draft",
    // Ponies
    "American Miniature Horse","Assateague / Chincoteague Pony","Australian Pony",
    "Camargue Pony","Connemara Pony","Dales Pony","Dartmoor Pony",
    "Eriskay Pony","Exmoor Pony","Falabella","Fell Pony","French Saddle Pony",
    "Gotland Pony","Highland Pony","Hackney Pony","Kerry Bog Pony",
    "Lundy Pony","Miniature Horse","New Forest Pony","Newfoundland Pony",
    "North American Sportpony","Pony of the Americas","Riding Pony","Shetland Pony",
    "Spanish Jennet","Welsh Pony (Section A)","Welsh Pony (Section B)",
    "Welsh Cob (Section C)","Welsh Cob (Section D)",
    // Gaited
    "Florida Cracker Horse","Kentucky Mountain Horse","Racking Horse",
    "Single-Footing Horse","Spotted Saddle Horse",
    "Mixed Breed / Grade Horse",
  ],
  ferret: [
    "Albino","Badger (Dark-masked)","Blaze","Champagne","Chocolate",
    "Chocolate Mitt","Cinnamon","Cinnamon Mitt","Dark-eyed White (DEW)",
    "Panda","Point (Siamese Pattern)","Roan","Sable","Sable Mitt",
    "Sable Panda","Silver","Silver Mitt","Solid Black","Standard Sable",
    "Sterling Silver","White (Dark-eyed)","Mixed / Pet Store",
  ],
  snake: [
    // Pythons
    "Ball Python — Albino","Ball Python — Axanthic","Ball Python — Banana",
    "Ball Python — Black Pastel","Ball Python — Bumblebee","Ball Python — Clown",
    "Ball Python — Fire","Ball Python — Ghost","Ball Python — Ivory",
    "Ball Python — Mojave","Ball Python — Pastel","Ball Python — Pied",
    "Ball Python — Pinstripe","Ball Python — Spider","Ball Python — Standard",
    "Ball Python — Ultramel","Bismarck Ringed Python","Blood Python (Short-tailed)",
    "Boa — Argentine","Boa — Argentine Albino","Boa — Brazilian Rainbow",
    "Boa — Columbian Red-tail","Boa — Dumeril's","Boa — Emerald Tree",
    "Boa — Hog Island","Boa — Kenyan Sand","Boa — Rosy",
    "Burmese Python — Albino","Burmese Python — Standard",
    "Carpet Python — Coastal","Carpet Python — Diamond",
    "Carpet Python — Jungle","Carpet Python — Irian Jaya",
    "Carpet Python — Inland","Carpet Python — Northwest",
    "Children's Python","Green Tree Python — Aru","Green Tree Python — Biak",
    "Green Tree Python — Sorong","Olive Python","Reticulated Python — Albino",
    "Reticulated Python — Standard","Reticulated Python — Super Dwarf",
    "Ringed Python","Scrub Python","Spotted Python","Stimson's Python",
    "White-lipped Python","Woma Python",
    // Colubrids
    "California Kingsnake — Albino","California Kingsnake — Desert",
    "California Kingsnake — Lavender","California Kingsnake — Standard",
    "Corn Snake — Albino (Amelanistic)","Corn Snake — Anerythristic",
    "Corn Snake — Blizzard","Corn Snake — Blood Red","Corn Snake — Butter",
    "Corn Snake — Candy Cane","Corn Snake — Ghost","Corn Snake — Hypomelanistic",
    "Corn Snake — Miami","Corn Snake — Motley","Corn Snake — Normal",
    "Corn Snake — Okeetee","Corn Snake — Snow","Corn Snake — Stripe",
    "Corn Snake — Tessera",
    "Eastern Hognose Snake","Western Hognose Snake — Albino",
    "Western Hognose Snake — Anaconda","Western Hognose Snake — Normal",
    "Florida Kingsnake","Garter Snake — Eastern","Garter Snake — Western",
    "Gray-banded Kingsnake","Gray Rat Snake","Honduran Milk Snake",
    "Milk Snake — Black","Milk Snake — Nelson's","Milk Snake — Pueblan",
    "Milk Snake — Sinaloan","Mountain Kingsnake (California)",
    "Prairie Kingsnake","Rat Snake — Black","Rat Snake — Great Plains",
    "Rat Snake — Russian","Rat Snake — Trans-Pecos","Rat Snake — Yellow",
    "Rough Green Snake","Scarlet Kingsnake","Smooth Green Snake",
    "Sunbeam Snake",
    // Boas (non-Python)
    "Annulated Tree Boa","Amazon Tree Boa — Standard",
    // Others
    "African Egg-eating Snake","File Snake","Indigo Snake (Eastern)",
    "Pine Snake","Water Moccasin (captive-bred only)","Mixed / Unknown",
  ],
  lizard: [
    // Geckos
    "African Fat-tailed Gecko — Albino","African Fat-tailed Gecko — Normal",
    "Crested Gecko — Bicolor","Crested Gecko — Dalmatian","Crested Gecko — Flame",
    "Crested Gecko — Harlequin","Crested Gecko — Phantom","Crested Gecko — Pinstripe",
    "Crested Gecko — Standard","Crested Gecko — Tiger",
    "Day Gecko — Giant (Phelsuma grandis)","Day Gecko — Gold Dust","Day Gecko — Peacock",
    "Gargoyle Gecko","Gecko — Tokay","Giant Leaf-tailed Gecko","Knob-tailed Gecko — Smooth",
    "Knob-tailed Gecko — Rough","Leachianus Gecko","Leopard Gecko — Albino (Tremper)",
    "Leopard Gecko — Blizzard","Leopard Gecko — Bold Stripe","Leopard Gecko — Eclipse",
    "Leopard Gecko — Giant (Super Giant)","Leopard Gecko — High Yellow",
    "Leopard Gecko — Hypo","Leopard Gecko — Lavender","Leopard Gecko — Mack Snow",
    "Leopard Gecko — Patternless","Leopard Gecko — RAPTOR","Leopard Gecko — Tangerine",
    "Leopard Gecko — Wild Type","Mourning Gecko","New Caledonian Giant Gecko",
    "Standing's Day Gecko","White-lined Gecko",
    // Agamas & Dragons
    "Ackie Monitor (Spiny-tailed)","Armadillo Lizard","Bearded Dragon — Citrus",
    "Bearded Dragon — Dunner","Bearded Dragon — Hypomelanistic",
    "Bearded Dragon — Leatherback","Bearded Dragon — Normal",
    "Bearded Dragon — Silkback","Bearded Dragon — Translucent",
    "Bearded Dragon — Zero","Chinese Water Dragon","Collared Lizard",
    "Frilled Dragon","Green Iguana","Ground Agama","Inland Bearded Dragon",
    "Mountain Horned Dragon","Sailfin Dragon","Spiny-tailed Iguana (Black)",
    "Spiny-tailed Lizard (Uromastyx) — Algerian","Uromastyx — Egyptian",
    "Uromastyx — Ornate","Uromastyx — Mali","Uromastyx — Saharan","Uromastyx — Yemeni",
    // Chameleons
    "Chameleon — Ambilobe Panther","Chameleon — Ambanja Panther",
    "Chameleon — Fischer's","Chameleon — Flap-necked","Chameleon — Four-horned",
    "Chameleon — Jackson's","Chameleon — Meller's","Chameleon — Namaqua",
    "Chameleon — Nosy Be Panther","Chameleon — Oustalet's","Chameleon — Pygmy",
    "Chameleon — Rudis","Chameleon — Senegal","Chameleon — Veiled",
    "Chameleon — Werner's",
    // Monitors
    "Monitor — Ackie (Pygmy)","Monitor — African Savannah","Monitor — Argus",
    "Monitor — Blackthroat","Monitor — Blue-tree","Monitor — Dumeril's",
    "Monitor — Mangrove","Monitor — Nile","Monitor — Peach-throat",
    "Monitor — Timor","Monitor — Water","Monitor — White-throated",
    // Skinks
    "Blue-tongued Skink — Indonesian","Blue-tongued Skink — Irian Jaya",
    "Blue-tongued Skink — Merauke","Blue-tongued Skink — Northern",
    "Blue-tongued Skink — Tanimbar","Blue-tongued Skink — Western (Tiliqua occipitalis)",
    "Fire Skink","Monkey-tailed Skink","Prehensile-tailed Skink",
    "Red-eyed Crocodile Skink","Schneider's Skink","Solomon Island Skink",
    "Stump-tailed Skink","Tiltiqua Rugosa (Sleepy Lizard)",
    // Tegus & Others
    "Black and White Tegu","Blue Tegu","Colombian Black and White Tegu",
    "Green Tegu","Red Tegu","Caiman Lizard","Green Anole","Brown Anole",
    "Italian Wall Lizard","Jeweled Lacerta","Knight Anole",
    "Plumed Basilisk (Green)","Plated Lizard — Rough-scaled",
    "Sand Lizard","Sandfish Skink","Six-lined Racerunner",
    "Emerald Swift","Mixed / Unknown",
  ],
};

// ─── Breed Themes ────────────────────────────────────────────────────────────
// Each animal type gets a base theme; breeds within share it
const TYPE_THEMES = {
  cat:       { bg: "#e8eaed", accent: "#6b7280", card: "#f5f6f7", text: "#2d3748", soft: "#f0f1f3", border: "#9ca3af", highlight: "#4b5563", emoji: "🐱", gradient: "linear-gradient(135deg, #c9cdd4 0%, #9ca3af 100%)", deco: ["🐾","✨","🐾","🌙","🐾","⭐","🐾"], font: "'Cormorant Garamond', serif" },
  dog:       { bg: "#fffbeb", accent: "#d97706", card: "#fefce8", text: "#78350f", soft: "#fde68a", border: "#f59e0b", highlight: "#b45309", emoji: "🐶", gradient: "linear-gradient(135deg, #fef3c7 0%, #fbbf24 100%)", deco: ["🐾","🌻","🐾","⭐","🐾","🌼","🐾"], font: "'Jost', sans-serif" },
  rabbit:    { bg: "#fdf2f8", accent: "#db2777", card: "#fce7f3", text: "#831843", soft: "#fbcfe8", border: "#f472b6", highlight: "#be185d", emoji: "🐰", gradient: "linear-gradient(135deg, #fdf2f8 0%, #f9a8d4 100%)", deco: ["🐰","🌸","🐰","🌷","🐰","🍀","🐰"], font: "'Cormorant Garamond', serif" },
  bird:      { bg: "#ecfeff", accent: "#0891b2", card: "#f0fdff", text: "#164e63", soft: "#cffafe", border: "#22d3ee", highlight: "#0e7490", emoji: "🦜", gradient: "linear-gradient(135deg, #ecfeff 0%, #67e8f9 100%)", deco: ["🦜","🌿","🦜","✨","🦜","🍃","🦜"], font: "'Cinzel', serif" },
  hamster:   { bg: "#fff7ed", accent: "#ea580c", card: "#ffedd5", text: "#7c2d12", soft: "#fed7aa", border: "#fb923c", highlight: "#c2410c", emoji: "🐹", gradient: "linear-gradient(135deg, #fff7ed 0%, #fdba74 100%)", deco: ["🐹","🌰","🐹","🌾","🐹","🍂","🐹"], font: "'Jost', sans-serif" },
  guinea_pig:{ bg: "#f0fdf4", accent: "#16a34a", card: "#dcfce7", text: "#14532d", soft: "#bbf7d0", border: "#4ade80", highlight: "#15803d", emoji: "🐾", gradient: "linear-gradient(135deg, #f0fdf4 0%, #86efac 100%)", deco: ["🐾","🌿","🌱","🐾","🍀","🌾","🐾"], font: "'Jost', sans-serif" },
  fish:      { bg: "#eff6ff", accent: "#2563eb", card: "#dbeafe", text: "#1e3a8a", soft: "#bfdbfe", border: "#60a5fa", highlight: "#1d4ed8", emoji: "🐟", gradient: "linear-gradient(135deg, #eff6ff 0%, #93c5fd 100%)", deco: ["🐟","🌊","🐠","💧","🐡","🌊","🐟"], font: "'Cinzel', serif" },
  turtle:    { bg: "#f0fdf4", accent: "#065f46", card: "#ecfdf5", text: "#064e3b", soft: "#a7f3d0", border: "#34d399", highlight: "#059669", emoji: "🐢", gradient: "linear-gradient(135deg, #f0fdf4 0%, #6ee7b7 100%)", deco: ["🐢","🌿","🐢","🍃","🐢","🌱","🐢"], font: "'Cormorant Garamond', serif" },
  horse:     { bg: "#fef3c7", accent: "#92400e", card: "#fffbeb", text: "#451a03", soft: "#fde68a", border: "#d97706", highlight: "#78350f", emoji: "🐴", gradient: "linear-gradient(135deg, #fef3c7 0%, #d97706 100%)", deco: ["🐴","🌾","🐴","🏇","🐴","🍂","🐴"], font: "'Playfair Display', serif" },
  ferret:    { bg: "#faf5ff", accent: "#7c3aed", card: "#f3e8ff", text: "#4c1d95", soft: "#ede9fe", border: "#a78bfa", highlight: "#5b21b6", emoji: "🦡", gradient: "linear-gradient(135deg, #faf5ff 0%, #c4b5fd 100%)", deco: ["🦡","✨","🦡","🌙","🦡","⭐","🦡"], font: "'Jost', sans-serif" },
  snake:     { bg: "#1a1a1a", accent: "#4ade80", card: "#111827", text: "#d1fae5", soft: "#064e3b", border: "#16a34a", highlight: "#22c55e", emoji: "🐍", gradient: "linear-gradient(135deg, #1f2937 0%, #064e3b 100%)", deco: ["🐍","🌿","🐍","🍃","🐍","🌑","🐍"], font: "'Cinzel', serif" },
  lizard:    { bg: "#fefce8", accent: "#ca8a04", card: "#fef9c3", text: "#713f12", soft: "#fde68a", border: "#eab308", highlight: "#a16207", emoji: "🦎", gradient: "linear-gradient(135deg, #fefce8 0%, #fde047 100%)", deco: ["🦎","🌞","🦎","🏜️","🦎","🌵","🦎"], font: "'Jost', sans-serif" },
};

function getTheme(type, breed) {
  return TYPE_THEMES[type] || TYPE_THEMES.cat;
}

// ─── Vaccine schedules ────────────────────────────────────────────────────────
const VACCINE_SCHEDULES = {
  cat: [
    { name: "FVRCP (Core)", intervalMonths: 12, color: "#ef4444" },
    { name: "Rabies", intervalMonths: 12, color: "#f97316" },
    { name: "FeLV", intervalMonths: 12, color: "#a855f7" },
    { name: "FIV", intervalMonths: 6, color: "#3b82f6" },
    { name: "Deworming", intervalMonths: 3, color: "#22c55e" },
    { name: "Vet Checkup", intervalMonths: 6, color: "#f59e0b" },
  ],
  dog: [
    { name: "DHPP (Core)", intervalMonths: 12, color: "#ef4444" },
    { name: "Rabies", intervalMonths: 12, color: "#f97316" },
    { name: "Bordetella", intervalMonths: 6, color: "#a855f7" },
    { name: "Leptospirosis", intervalMonths: 12, color: "#3b82f6" },
    { name: "Canine Influenza", intervalMonths: 12, color: "#06b6d4" },
    { name: "Deworming", intervalMonths: 3, color: "#22c55e" },
    { name: "Flea & Tick Treatment", intervalMonths: 1, color: "#f43f5e" },
    { name: "Vet Checkup", intervalMonths: 6, color: "#f59e0b" },
  ],
  rabbit: [
    { name: "RHDV2 (Rabbit Hemorrhagic)", intervalMonths: 12, color: "#ef4444" },
    { name: "Myxomatosis", intervalMonths: 12, color: "#f97316" },
    { name: "Vet Checkup", intervalMonths: 6, color: "#f59e0b" },
    { name: "Nail Trim", intervalMonths: 2, color: "#22c55e" },
    { name: "Dental Check", intervalMonths: 6, color: "#3b82f6" },
  ],
  bird: [
    { name: "Polyomavirus Vaccine", intervalMonths: 12, color: "#ef4444" },
    { name: "Psittacosis Test", intervalMonths: 12, color: "#f97316" },
    { name: "Vet Checkup", intervalMonths: 6, color: "#f59e0b" },
    { name: "Beak & Nail Trim", intervalMonths: 3, color: "#22c55e" },
    { name: "Parasite Screening", intervalMonths: 6, color: "#a855f7" },
  ],
  hamster: [
    { name: "Vet Checkup", intervalMonths: 6, color: "#f59e0b" },
    { name: "Dental Check", intervalMonths: 6, color: "#3b82f6" },
    { name: "Parasite Screening", intervalMonths: 6, color: "#a855f7" },
  ],
  guinea_pig: [
    { name: "Vet Checkup", intervalMonths: 6, color: "#f59e0b" },
    { name: "Vitamin C Supplement Review", intervalMonths: 3, color: "#22c55e" },
    { name: "Dental Check", intervalMonths: 6, color: "#3b82f6" },
    { name: "Nail Trim", intervalMonths: 2, color: "#f97316" },
  ],
  fish: [
    { name: "Water Quality Test", intervalMonths: 1, color: "#3b82f6" },
    { name: "Tank Deep Clean", intervalMonths: 3, color: "#22c55e" },
    { name: "Parasite Treatment", intervalMonths: 6, color: "#ef4444" },
    { name: "Filter Maintenance", intervalMonths: 1, color: "#f97316" },
    { name: "Vet / Aquarist Checkup", intervalMonths: 12, color: "#f59e0b" },
  ],
  turtle: [
    { name: "Vet Checkup", intervalMonths: 12, color: "#f59e0b" },
    { name: "Parasite Screening", intervalMonths: 6, color: "#a855f7" },
    { name: "Shell Inspection", intervalMonths: 3, color: "#22c55e" },
    { name: "UV Lamp Replacement", intervalMonths: 6, color: "#f97316" },
    { name: "Salmonella Screening", intervalMonths: 12, color: "#ef4444" },
  ],
  horse: [
    { name: "Tetanus", intervalMonths: 12, color: "#ef4444" },
    { name: "Eastern/Western Encephalomyelitis", intervalMonths: 12, color: "#f97316" },
    { name: "Rabies", intervalMonths: 12, color: "#dc2626" },
    { name: "Influenza", intervalMonths: 6, color: "#a855f7" },
    { name: "Rhinopneumonitis (EHV)", intervalMonths: 6, color: "#3b82f6" },
    { name: "West Nile Virus", intervalMonths: 12, color: "#06b6d4" },
    { name: "Strangles", intervalMonths: 12, color: "#f43f5e" },
    { name: "Deworming", intervalMonths: 3, color: "#22c55e" },
    { name: "Dental Float", intervalMonths: 12, color: "#f59e0b" },
    { name: "Farrier (Hoof)", intervalMonths: 2, color: "#84cc16" },
    { name: "Vet Checkup", intervalMonths: 6, color: "#eab308" },
  ],
  ferret: [
    { name: "Rabies", intervalMonths: 12, color: "#ef4444" },
    { name: "Distemper (CDV)", intervalMonths: 12, color: "#f97316" },
    { name: "Influenza Monitoring", intervalMonths: 6, color: "#a855f7" },
    { name: "Adrenal Disease Check", intervalMonths: 6, color: "#3b82f6" },
    { name: "Vet Checkup", intervalMonths: 6, color: "#f59e0b" },
  ],
  snake: [
    { name: "Vet Checkup", intervalMonths: 12, color: "#f59e0b" },
    { name: "Parasite Screening", intervalMonths: 6, color: "#a855f7" },
    { name: "Respiratory Check", intervalMonths: 6, color: "#3b82f6" },
    { name: "Fecal Test", intervalMonths: 6, color: "#22c55e" },
    { name: "Shedding Monitor", intervalMonths: 2, color: "#4ade80" },
  ],
  lizard: [
    { name: "Vet Checkup", intervalMonths: 12, color: "#f59e0b" },
    { name: "Parasite Screening", intervalMonths: 6, color: "#a855f7" },
    { name: "UV Lamp Replacement", intervalMonths: 6, color: "#f97316" },
    { name: "Fecal Test", intervalMonths: 6, color: "#22c55e" },
    { name: "Metabolic Bone Check", intervalMonths: 12, color: "#ef4444" },
  ],
};

const FREE_PET_LIMIT = 4;
const PREMIUM_PRICE = 4.99;

const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const DAYS = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];

// ─── Helpers ──────────────────────────────────────────────────────────────────
function computeNextDates(vaccinHistory, petType) {
  const schedule = VACCINE_SCHEDULES[petType] || VACCINE_SCHEDULES.cat;
  const events = {};
  const now = new Date();
  now.setHours(0, 0, 0, 0);

  schedule.forEach(vaccine => {
    const lastDateStr = vaccinHistory[vaccine.name];
    if (lastDateStr) {
      const last = new Date(lastDateStr);
      const next = new Date(last);
      next.setMonth(next.getMonth() + vaccine.intervalMonths);
      // If next due date is already in the past, keep rolling forward by the interval until it's upcoming
      while (next < now) {
        next.setMonth(next.getMonth() + vaccine.intervalMonths);
      }
      const key = `${next.getFullYear()}-${next.getMonth()}-${next.getDate()}`;
      if (!events[key]) events[key] = [];
      events[key].push({ ...vaccine });
    }
  });
  return events;
}

function getDaysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
}
function getFirstDay(year, month) {
  return new Date(year, month, 1).getDay();
}

// ─── Paw SVG ─────────────────────────────────────────────────────────────────
function PawPrint({ size = 20, color = "#00000033", style = {} }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" style={style} fill={color}>
      <ellipse cx="50" cy="75" rx="22" ry="18" />
      <ellipse cx="22" cy="52" rx="11" ry="14" />
      <ellipse cx="78" cy="52" rx="11" ry="14" />
      <ellipse cx="35" cy="32" rx="9" ry="12" />
      <ellipse cx="65" cy="32" rx="9" ry="12" />
    </svg>
  );
}

// ─── Floating paws background ─────────────────────────────────────────────────
function FloatingPaws({ color }) {
  const paws = Array.from({ length: 12 }, (_, i) => ({
    left: `${(i * 8.3 + 2) % 100}%`,
    top: `${(i * 13 + 5) % 100}%`,
    size: 16 + (i % 3) * 8,
    opacity: 0.08 + (i % 4) * 0.03,
    rotate: (i * 37) % 360,
  }));
  return (
    <div style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none" }}>
      {paws.map((p, i) => (
        <div key={i} style={{
          position: "absolute", left: p.left, top: p.top,
          transform: `rotate(${p.rotate}deg)`, opacity: p.opacity,
        }}>
          <PawPrint size={p.size} color={color} />
        </div>
      ))}
    </div>
  );
}

// ─── Reminder Pill with hover tooltip ────────────────────────────────────────
function ReminderPill({ vaccine, upcoming, theme }) {
  const [hovered, setHovered] = useState(false);

  const formatDate = (d) => {
    return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  };

  const isNext = (d, i) => i === 0;
  const now = new Date(); now.setHours(0,0,0,0);
  const daysUntil = upcoming.length > 0
    ? Math.ceil((upcoming[0] - now) / (1000 * 60 * 60 * 24))
    : null;

  return (
    <div style={{ position: "relative", display: "inline-block" }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}>
      <div style={{
        display: "flex", alignItems: "center", gap: 5, padding: "4px 10px",
        borderRadius: 20, background: hovered ? vaccine.color : theme.soft,
        border: `1.5px solid ${hovered ? vaccine.color : theme.border + "66"}`,
        cursor: "default", transition: "all 0.2s",
      }}>
        <div style={{ width: 8, height: 8, borderRadius: "50%", background: hovered ? "#fff" : vaccine.color, flexShrink: 0 }} />
        <span style={{ fontSize: 11, color: hovered ? "#fff" : theme.text, fontWeight: 700, whiteSpace: "nowrap" }}>
          {vaccine.name}
        </span>
        {daysUntil !== null && (
          <span style={{
            fontSize: 10, fontWeight: 800, padding: "1px 5px", borderRadius: 8,
            background: hovered ? "rgba(255,255,255,0.25)" : vaccine.color + "22",
            color: hovered ? "#fff" : vaccine.color,
          }}>
            {daysUntil === 0 ? "today" : daysUntil < 0 ? "overdue" : `${daysUntil}d`}
          </span>
        )}
      </div>

      {hovered && upcoming.length > 0 && (
        <div style={{
          position: "absolute", bottom: "calc(100% + 8px)", left: 0,
          background: "#1e1b4b", borderRadius: 14, padding: "12px 14px",
          boxShadow: "0 8px 32px rgba(0,0,0,0.35)", zIndex: 999,
          minWidth: 200, border: "1px solid rgba(255,255,255,0.12)",
          fontFamily: "'Jost', sans-serif",
          animation: "fadeUp 0.15s ease",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
            <div style={{ width: 10, height: 10, borderRadius: "50%", background: vaccine.color }} />
            <span style={{ color: "#fff", fontWeight: 800, fontSize: 12 }}>{vaccine.name}</span>
            <span style={{ color: "#64748b", fontSize: 10 }}>every {vaccine.intervalMonths}mo</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
            {upcoming.map((d, i) => (
              <div key={i} style={{
                display: "flex", alignItems: "center", gap: 8,
                padding: "5px 8px", borderRadius: 8,
                background: i === 0 ? vaccine.color + "22" : "rgba(255,255,255,0.04)",
                border: i === 0 ? `1px solid ${vaccine.color}55` : "1px solid transparent",
              }}>
                <span style={{ fontSize: 13, lineHeight: 1 }}>{i === 0 ? "🔔" : "📅"}</span>
                <span style={{ color: i === 0 ? "#fff" : "#94a3b8", fontSize: 12, fontWeight: i === 0 ? 800 : 500 }}>
                  {formatDate(d)}
                </span>
                {i === 0 && (
                  <span style={{ marginLeft: "auto", fontSize: 10, fontWeight: 700,
                    color: vaccine.color, background: vaccine.color + "33",
                    padding: "1px 6px", borderRadius: 6 }}>
                    next
                  </span>
                )}
              </div>
            ))}
          </div>
          {/* Tooltip arrow */}
          <div style={{
            position: "absolute", bottom: -6, left: 16,
            width: 12, height: 12, background: "#1e1b4b",
            transform: "rotate(45deg)", border: "1px solid rgba(255,255,255,0.12)",
            borderTop: "none", borderLeft: "none",
          }} />
        </div>
      )}
    </div>
  );
}

// ─── Sign In ──────────────────────────────────────────────────────────────────
function SignIn({ onAuth }) {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [name, setName] = useState("");
  const [err, setErr] = useState("");

  const handleSubmit = () => {
    if (!email || !pass) return setErr("Please fill all fields.");
    if (mode === "register" && !name) return setErr("Enter your name.");
    const key = `furrylife_user_${email}`;
    if (mode === "register") {
      if (localStorage.getItem(key)) return setErr("Account already exists. Please sign in.");
      const newUser = { email, pass, name, pets: [] };
      localStorage.setItem(key, JSON.stringify(newUser));
      onAuth(newUser);
    } else {
      const raw = localStorage.getItem(key);
      if (!raw) return setErr("No account found. Please register.");
      const userData = JSON.parse(raw);
      if (userData.pass !== pass) return setErr("Incorrect password.");
      onAuth(userData);
    }
  };

  return (
    <div style={{
      minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center",
      background: "linear-gradient(160deg, #0a0a1a 0%, #0f172a 40%, #1a0a2e 70%, #0a1628 100%)",
      fontFamily: "'Jost', sans-serif", position: "relative", overflow: "hidden",
    }}>
      {/* Decorative orbs */}
      <div style={{ position:"absolute", width:400, height:400, borderRadius:"50%", background:"radial-gradient(circle, rgba(99,102,241,0.15) 0%, transparent 70%)", top:"-10%", left:"-5%", pointerEvents:"none" }} />
      <div style={{ position:"absolute", width:300, height:300, borderRadius:"50%", background:"radial-gradient(circle, rgba(236,72,153,0.1) 0%, transparent 70%)", bottom:"5%", right:"5%", pointerEvents:"none" }} />
      <FloatingPaws color="#ffffff" />

      <div style={{ position:"relative", zIndex:1, width:"100%", maxWidth:420, padding:"0 20px", animation:"fadeIn 0.5s ease" }}>
        {/* Brand header */}
        <div style={{ textAlign:"center", marginBottom:32 }}>
          <div style={{ fontSize:56, marginBottom:10, filter:"drop-shadow(0 4px 16px rgba(99,102,241,0.5))" }}>🐾</div>
          <h1 style={{ color:"#fff", fontSize:34, fontWeight:900, margin:"0 0 6px",
            fontFamily:"'Cinzel', serif", letterSpacing:3,
            textShadow:"0 0 40px rgba(139,92,246,0.6)" }}>The Furry Life</h1>
          <p style={{ color:"rgba(255,255,255,0.45)", fontSize:13, margin:0, letterSpacing:1, textTransform:"uppercase" }}>
            Your companion's wellness calendar
          </p>
        </div>

        {/* Card */}
        <div style={{
          background:"rgba(255,255,255,0.05)", backdropFilter:"blur(24px)",
          border:"1px solid rgba(255,255,255,0.1)", borderRadius:24,
          padding:"32px 32px 28px", boxShadow:"0 24px 64px rgba(0,0,0,0.5)",
        }}>
          {/* Tabs */}
          <div style={{ display:"flex", marginBottom:28, background:"rgba(0,0,0,0.3)", borderRadius:12, padding:3 }}>
            {[{id:"login",label:"Sign In"},{id:"register",label:"Register"}].map(m => (
              <button key={m.id} onClick={() => { setMode(m.id); setErr(""); }} style={{
                flex:1, padding:"9px 0", borderRadius:9, border:"none", cursor:"pointer",
                background: mode===m.id ? "rgba(255,255,255,0.92)" : "transparent",
                color: mode===m.id ? "#0f172a" : "rgba(255,255,255,0.5)",
                fontWeight:700, fontSize:13, transition:"all 0.2s",
                fontFamily:"'Jost', sans-serif", letterSpacing:0.5,
                boxShadow: mode===m.id ? "0 2px 8px rgba(0,0,0,0.3)" : "none",
              }}>{m.label}</button>
            ))}
          </div>

          {/* Fields */}
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {mode==="register" && (
              <div style={{ position:"relative" }}>
                <span style={{ position:"absolute", left:14, top:"50%", transform:"translateY(-50%)", fontSize:16, opacity:0.5 }}>👤</span>
                <input value={name} onChange={e => setName(e.target.value)}
                  placeholder="Your full name" style={{ ...inputStyle, paddingLeft:40 }} />
              </div>
            )}
            <div style={{ position:"relative" }}>
              <span style={{ position:"absolute", left:14, top:"50%", transform:"translateY(-50%)", fontSize:15, opacity:0.5 }}>✉️</span>
              <input value={email} onChange={e => setEmail(e.target.value)}
                placeholder="Email address" type="email" style={{ ...inputStyle, paddingLeft:40 }} />
            </div>
            <div style={{ position:"relative" }}>
              <span style={{ position:"absolute", left:14, top:"50%", transform:"translateY(-50%)", fontSize:15, opacity:0.5 }}>🔒</span>
              <input value={pass} onChange={e => setPass(e.target.value)}
                placeholder="Password" type="password" style={{ ...inputStyle, paddingLeft:40, marginBottom:0 }} />
            </div>
          </div>

          {err && (
            <div style={{ margin:"12px 0 0", padding:"9px 12px", borderRadius:10,
              background:"rgba(239,68,68,0.15)", border:"1px solid rgba(239,68,68,0.3)",
              color:"#fca5a5", fontSize:13 }}>
              ⚠️ {err}
            </div>
          )}

          <button onClick={handleSubmit} style={{
            width:"100%", padding:"13px 0", borderRadius:12, border:"none", marginTop:16,
            background:"linear-gradient(135deg, #4f46e5 0%, #7c3aed 50%, #be185d 100%)",
            color:"#fff", fontWeight:700, fontSize:15, cursor:"pointer",
            fontFamily:"'Cinzel', serif", letterSpacing:1,
            boxShadow:"0 4px 20px rgba(99,102,241,0.4)",
            transition:"all 0.2s",
          }}
            onMouseEnter={e => e.currentTarget.style.boxShadow = "0 6px 28px rgba(99,102,241,0.65)"}
            onMouseLeave={e => e.currentTarget.style.boxShadow = "0 4px 20px rgba(99,102,241,0.4)"}
          >
            {mode==="login" ? "Enter the Sanctuary 🐾" : "Join The Furry Life 🐾"}
          </button>

          <p style={{ textAlign:"center", marginTop:16, marginBottom:0, color:"rgba(255,255,255,0.3)", fontSize:12 }}>
            {mode==="login"
              ? <>No account? <span onClick={() => { setMode("register"); setErr(""); }} style={{ color:"#818cf8", cursor:"pointer", textDecoration:"underline" }}>Register here</span></>
              : <>Already have an account? <span onClick={() => { setMode("login"); setErr(""); }} style={{ color:"#818cf8", cursor:"pointer", textDecoration:"underline" }}>Sign in</span></>
            }
          </p>
        </div>

        {/* Footer */}
        <p style={{ textAlign:"center", color:"rgba(255,255,255,0.2)", fontSize:11, marginTop:20, letterSpacing:0.5 }}>
          🔒 Your data stays in your browser
        </p>
      </div>
    </div>
  );
}
const inputStyle = {
  width: "100%", padding: "11px 14px", marginBottom: 12, borderRadius: 10,
  border: "1px solid rgba(255,255,255,0.2)", background: "rgba(255,255,255,0.1)",
  color: "#fff", fontSize: 14, outline: "none", boxSizing: "border-box",
  fontFamily: "'Jost', sans-serif",
};

// ─── Upgrade Modal ─────────────────────────────────────────────────────────────
function UpgradeModal({ onClose, onUpgrade }) {
  const [step, setStep] = useState("pitch"); // pitch | payment | success
  const [cardNum, setCardNum] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const formatCard = (v) => v.replace(/\D/g,"").slice(0,16).replace(/(\d{4})/g,"$1 ").trim();
  const formatExpiry = (v) => { const d = v.replace(/\D/g,"").slice(0,4); return d.length > 2 ? d.slice(0,2)+"/"+d.slice(2) : d; };

  const handlePay = () => {
    if (!name || cardNum.replace(/\s/g,"").length < 16 || expiry.length < 5 || cvv.length < 3)
      return setErr("Please fill all card details.");
    setErr("");
    setLoading(true);
    setTimeout(() => { setLoading(false); setStep("success"); }, 1800);
  };

  const features = [
    { icon: "🐾", text: "Unlimited pets" },
    { icon: "📅", text: "Full 2-year reminder schedule" },
    { icon: "🎨", text: "All breed themes unlocked" },
    { icon: "🔔", text: "Priority vaccine alerts" },
    { icon: "📊", text: "Health history export (coming soon)" },
    { icon: "⭐", text: "Premium support" },
  ];

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", zIndex: 200,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "'Jost', sans-serif", padding: 16, backdropFilter: "blur(4px)",
    }}>
      <div style={{
        background: "#0f172a", borderRadius: 24, width: 460, maxHeight: "92vh",
        overflowY: "auto", boxSizing: "border-box",
        border: "1px solid rgba(139,92,246,0.3)",
        boxShadow: "0 0 60px rgba(99,102,241,0.25), 0 25px 60px rgba(0,0,0,0.6)",
        animation: "fadeIn 0.3s ease",
      }}>

        {step === "pitch" && (
          <div style={{ padding: "32px 32px 28px" }}>
            {/* Header */}
            <div style={{ textAlign: "center", marginBottom: 28 }}>
              <div style={{ fontSize: 44, marginBottom: 8 }}>✨</div>
              <h2 style={{ margin: "0 0 6px", color: "#fff", fontFamily: "'Cinzel', serif", fontSize: 22, letterSpacing: 1 }}>
                Upgrade to Premium
              </h2>
              <p style={{ color: "#94a3b8", margin: 0, fontSize: 14 }}>
                You've reached the <strong style={{ color: "#f59e0b" }}>4 pet limit</strong> on the free plan.
              </p>
            </div>

            {/* Price */}
            <div style={{
              background: "linear-gradient(135deg, rgba(99,102,241,0.15), rgba(168,85,247,0.15))",
              border: "1px solid rgba(139,92,246,0.35)", borderRadius: 16,
              padding: "20px 24px", marginBottom: 24, textAlign: "center",
            }}>
              <span style={{ color: "#a78bfa", fontSize: 13, textTransform: "uppercase", letterSpacing: 1 }}>Monthly</span>
              <div style={{ color: "#fff", fontSize: 42, fontWeight: 900, fontFamily: "'Cinzel', serif", lineHeight: 1.1 }}>
                ${PREMIUM_PRICE}
                <span style={{ fontSize: 16, color: "#94a3b8", fontFamily: "'Jost', sans-serif", fontWeight: 400 }}>/mo</span>
              </div>
              <p style={{ color: "#6ee7b7", fontSize: 13, margin: "6px 0 0", fontWeight: 600 }}>✓ Cancel anytime</p>
            </div>

            {/* Features */}
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 28 }}>
              {features.map((f, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <span style={{ fontSize: 18, width: 28, textAlign: "center" }}>{f.icon}</span>
                  <span style={{ color: "#e2e8f0", fontSize: 14 }}>{f.text}</span>
                </div>
              ))}
            </div>

            <button onClick={() => setStep("payment")} style={{
              width: "100%", padding: "14px 0", borderRadius: 12, border: "none",
              background: "linear-gradient(135deg, #4f46e5, #7c3aed, #be185d)",
              color: "#fff", fontWeight: 700, fontSize: 15, cursor: "pointer",
              fontFamily: "'Cinzel', serif", letterSpacing: 0.8,
              boxShadow: "0 4px 20px rgba(99,102,241,0.45)",
            }}>
              Upgrade Now — ${PREMIUM_PRICE}/mo
            </button>
            <button onClick={onClose} style={{
              width: "100%", padding: "10px 0", marginTop: 10, borderRadius: 12,
              border: "1px solid rgba(255,255,255,0.1)", background: "transparent",
              color: "#64748b", cursor: "pointer", fontSize: 13, fontFamily: "'Jost', sans-serif",
            }}>Maybe later</button>
          </div>
        )}

        {step === "payment" && (
          <div style={{ padding: "32px 32px 28px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 24 }}>
              <button onClick={() => setStep("pitch")} style={{
                background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: 20, padding: 0,
              }}>←</button>
              <h2 style={{ margin: 0, color: "#fff", fontFamily: "'Cinzel', serif", fontSize: 20 }}>Payment Details</h2>
              <div style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
                {["💳","🔒"].map((e,i) => <span key={i} style={{ fontSize: 18 }}>{e}</span>)}
              </div>
            </div>

            <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: 14, padding: "16px 18px", marginBottom: 20,
              border: "1px solid rgba(255,255,255,0.08)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <p style={{ margin: 0, color: "#94a3b8", fontSize: 12 }}>Total today</p>
                <p style={{ margin: 0, color: "#fff", fontSize: 22, fontWeight: 800, fontFamily: "'Cinzel', serif" }}>${PREMIUM_PRICE}</p>
              </div>
              <div style={{ textAlign: "right" }}>
                <p style={{ margin: 0, color: "#6ee7b7", fontSize: 12, fontWeight: 600 }}>Premium Monthly</p>
                <p style={{ margin: 0, color: "#64748b", fontSize: 11 }}>Renews monthly · Cancel anytime</p>
              </div>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <div>
                <label style={{ color: "#94a3b8", fontSize: 12, fontWeight: 600, display: "block", marginBottom: 6 }}>CARDHOLDER NAME</label>
                <input value={name} onChange={e => setName(e.target.value)} placeholder="Jane Smith"
                  style={{ ...payInput }} />
              </div>
              <div>
                <label style={{ color: "#94a3b8", fontSize: 12, fontWeight: 600, display: "block", marginBottom: 6 }}>CARD NUMBER</label>
                <input value={cardNum} onChange={e => setCardNum(formatCard(e.target.value))} placeholder="1234 5678 9012 3456"
                  style={{ ...payInput }} maxLength={19} />
              </div>
              <div style={{ display: "flex", gap: 12 }}>
                <div style={{ flex: 1 }}>
                  <label style={{ color: "#94a3b8", fontSize: 12, fontWeight: 600, display: "block", marginBottom: 6 }}>EXPIRY</label>
                  <input value={expiry} onChange={e => setExpiry(formatExpiry(e.target.value))} placeholder="MM/YY"
                    style={{ ...payInput }} maxLength={5} />
                </div>
                <div style={{ flex: 1 }}>
                  <label style={{ color: "#94a3b8", fontSize: 12, fontWeight: 600, display: "block", marginBottom: 6 }}>CVV</label>
                  <input value={cvv} onChange={e => setCvv(e.target.value.replace(/\D/g,"").slice(0,4))} placeholder="123"
                    style={{ ...payInput }} maxLength={4} />
                </div>
              </div>
            </div>

            {err && <div style={{ marginTop: 12, color: "#fca5a5", fontSize: 13, padding: "8px 12px",
              background: "rgba(239,68,68,0.12)", borderRadius: 8, border: "1px solid rgba(239,68,68,0.25)" }}>⚠️ {err}</div>}

            <button onClick={handlePay} disabled={loading} style={{
              width: "100%", padding: "14px 0", borderRadius: 12, border: "none", marginTop: 20,
              background: loading ? "rgba(99,102,241,0.4)" : "linear-gradient(135deg, #4f46e5, #7c3aed)",
              color: "#fff", fontWeight: 700, fontSize: 15, cursor: loading ? "not-allowed" : "pointer",
              fontFamily: "'Cinzel', serif", letterSpacing: 0.8,
              boxShadow: loading ? "none" : "0 4px 20px rgba(99,102,241,0.4)",
              transition: "all 0.2s",
            }}>
              {loading ? "Processing..." : `Pay $${PREMIUM_PRICE} →`}
            </button>
            <p style={{ textAlign: "center", color: "#374151", fontSize: 11, marginTop: 12 }}>
              🔒 Secured with 256-bit encryption
            </p>
          </div>
        )}

        {step === "success" && (
          <div style={{ padding: "40px 32px", textAlign: "center" }}>
            <div style={{ fontSize: 64, marginBottom: 16, animation: "fadeIn 0.4s ease" }}>🎉</div>
            <h2 style={{ color: "#fff", fontFamily: "'Cinzel', serif", fontSize: 24, margin: "0 0 10px", letterSpacing: 1 }}>
              Welcome to Premium!
            </h2>
            <p style={{ color: "#94a3b8", marginBottom: 28, lineHeight: 1.6 }}>
              You now have <strong style={{ color: "#a78bfa" }}>unlimited pets</strong> and all premium features unlocked. Thank you for supporting The Furry Life! 🐾
            </p>
            <button onClick={onUpgrade} style={{
              width: "100%", padding: "14px 0", borderRadius: 12, border: "none",
              background: "linear-gradient(135deg, #4f46e5, #7c3aed, #be185d)",
              color: "#fff", fontWeight: 700, fontSize: 15, cursor: "pointer",
              fontFamily: "'Cinzel', serif", letterSpacing: 0.8,
              boxShadow: "0 4px 20px rgba(99,102,241,0.45)",
            }}>Start Adding Pets ✨</button>
          </div>
        )}
      </div>
    </div>
  );
}
const payInput = {
  width: "100%", padding: "11px 14px", borderRadius: 10, boxSizing: "border-box",
  border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.06)",
  color: "#fff", fontSize: 14, outline: "none", fontFamily: "'Jost', sans-serif",
};

// ─── Add Pet Modal ─────────────────────────────────────────────────────────────
function AddPetModal({ onAdd, onClose }) {
  const [name, setName] = useState("");
  const [type, setType] = useState("cat");
  const [gender, setGender] = useState("male");
  const [breed, setBreed] = useState(BREEDS_BY_TYPE["cat"][0]);
  const [dob, setDob] = useState("");
  const [vaccines, setVaccines] = useState({});

  const breeds = BREEDS_BY_TYPE[type] || [];
  const vaccineList = VACCINE_SCHEDULES[type] || [];

  useEffect(() => {
    setBreed((BREEDS_BY_TYPE[type] || ["Mixed"])[0]);
    setVaccines({});
  }, [type]);

  const handleAdd = () => {
    if (!name) return;
    onAdd({ id: Date.now(), name, type, gender, breed, dob, vaccineHistory: vaccines });
    onClose();
  };

  const currentAnimal = ANIMAL_TYPES.find(a => a.id === type);

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 100,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "'Jost', sans-serif", padding: 16,
    }}>
      <div style={{
        background: "#fff", borderRadius: 24, padding: "28px 32px",
        width: 500, maxHeight: "92vh", overflowY: "auto", boxSizing: "border-box",
        boxShadow: "0 25px 60px rgba(0,0,0,0.35)",
      }}>
        <h2 style={{ margin: "0 0 20px", fontSize: 22, fontWeight: 700, color: "#1a1a2e", fontFamily: "'Cinzel', serif" }}>
          Add a New Companion
        </h2>

        <label style={labelStyle}>Name</label>
        <input value={name} onChange={e => setName(e.target.value)}
          placeholder="e.g. Luna" style={modalInput} />

        <label style={labelStyle}>Animal Type</label>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 7, marginBottom: 16 }}>
          {ANIMAL_TYPES.map(a => (
            <button key={a.id} onClick={() => setType(a.id)} style={{
              padding: "8px 4px", borderRadius: 10, border: "2px solid",
              borderColor: type === a.id ? "#3b82f6" : "#e5e7eb",
              background: type === a.id ? "#eff6ff" : "#f9fafb",
              fontWeight: 600, cursor: "pointer", fontSize: 12,
              fontFamily: "'Jost', sans-serif", textAlign: "center",
              display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
            }}>
              <span style={{ fontSize: 18 }}>{a.emoji}</span>
              <span style={{ fontSize: 10, color: type === a.id ? "#1d4ed8" : "#374151" }}>{a.label}</span>
            </button>
          ))}
        </div>

        <label style={labelStyle}>Gender</label>
        <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
          {["male","female","unknown"].map(g => (
            <button key={g} onClick={() => setGender(g)} style={{
              flex: 1, padding: "9px 0", borderRadius: 10, border: "2px solid",
              borderColor: gender === g ? "#8b5cf6" : "#e5e7eb",
              background: gender === g ? "#f5f3ff" : "#f9fafb",
              fontWeight: 600, cursor: "pointer", fontSize: 13,
              fontFamily: "'Jost', sans-serif", textTransform: "capitalize",
            }}>{g === "male" ? "♂ Male" : g === "female" ? "♀ Female" : "? Unknown"}</button>
          ))}
        </div>

        <label style={labelStyle}>Breed / Variety ({breeds.length} options)</label>
        <select value={breed} onChange={e => setBreed(e.target.value)} style={modalInput}>
          {breeds.map(b => <option key={b}>{b}</option>)}
        </select>

        <label style={labelStyle}>Date of Birth</label>
        <input type="date" value={dob} onChange={e => setDob(e.target.value)} style={modalInput} />

        <label style={labelStyle}>Last care/vaccine dates (optional)</label>
        <div style={{ background: "#f8fafc", borderRadius: 12, padding: "10px 12px", marginBottom: 16 }}>
          {vaccineList.map(v => (
            <div key={v.name} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: v.color, flexShrink: 0 }} />
              <span style={{ fontSize: 12, flex: 1, color: "#374151", fontWeight: 600 }}>{v.name}</span>
              <input type="date" value={vaccines[v.name] || ""}
                onChange={e => setVaccines(prev => ({ ...prev, [v.name]: e.target.value }))}
                style={{ ...modalInput, width: 150, margin: 0, fontSize: 12, padding: "6px 10px" }} />
            </div>
          ))}
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
          <button onClick={onClose} style={{
            flex: 1, padding: "12px 0", borderRadius: 12, border: "2px solid #e5e7eb",
            background: "#fff", fontWeight: 600, cursor: "pointer",
            fontFamily: "'Jost', sans-serif", color: "#374151",
          }}>Cancel</button>
          <button onClick={handleAdd} style={{
            flex: 2, padding: "12px 0", borderRadius: 12, border: "none",
            background: "linear-gradient(135deg, #3b82f6, #8b5cf6)",
            color: "#fff", fontWeight: 700, fontSize: 15, cursor: "pointer",
            fontFamily: "'Cinzel', serif", letterSpacing: 0.5,
          }}>Add {currentAnimal ? currentAnimal.emoji : "🐾"}</button>
        </div>
      </div>
    </div>
  );
}
const labelStyle = { display: "block", fontWeight: 700, color: "#374151", marginBottom: 6, fontSize: 13 };
const modalInput = {
  width: "100%", padding: "10px 14px", marginBottom: 16, borderRadius: 10,
  border: "1.5px solid #e5e7eb", background: "#f9fafb", fontSize: 14,
  outline: "none", boxSizing: "border-box", fontFamily: "'Jost', sans-serif",
};

// ─── Calendar ─────────────────────────────────────────────────────────────────
function PetCalendar({ pet, onRemove }) {
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());

  const theme = getTheme(pet.type, pet.breed);
  const events = computeNextDates(pet.vaccineHistory || {}, pet.type);

  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDay(year, month);
  const isCurrentMonth = year === today.getFullYear() && month === today.getMonth();

  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const prevMonth = () => {
    if (month === 0) { setMonth(11); setYear(y => y - 1); }
    else setMonth(m => m - 1);
  };
  const nextMonth = () => {
    if (month === 11) { setMonth(0); setYear(y => y + 1); }
    else setMonth(m => m + 1);
  };

  return (
    <div style={{
      borderRadius: 24, overflow: "hidden", boxShadow: "0 8px 32px rgba(0,0,0,0.12)",
      position: "relative", fontFamily: theme.font,
    }}>
      {/* Header */}
      <div style={{
        background: theme.gradient, padding: "28px 28px 20px",
        position: "relative", overflow: "hidden",
      }}>
        <FloatingPaws color={theme.accent} />
        <div style={{ position: "relative", zIndex: 1 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
            <div>
              <h2 style={{ margin: 0, color: theme.text, fontSize: 22, fontWeight: 900 }}>
                {theme.emoji} {pet.name}
              </h2>
              <p style={{ margin: 0, color: theme.highlight, fontSize: 13, opacity: 0.8 }}>
                {pet.breed} · {pet.gender}
              </p>
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <button onClick={prevMonth} style={navBtn(theme)}>‹</button>
              <span style={{ fontWeight: 800, color: theme.text, minWidth: 140, textAlign: "center", fontSize: 15, fontFamily: "'Cinzel', serif" }}>
                {MONTHS[month]} {year}
              </span>
              <button onClick={nextMonth} style={navBtn(theme)}>›</button>
              <button onClick={() => onRemove(pet.id)} title="Remove pet" style={{
                width: 32, height: 32, borderRadius: 8, border: "1.5px solid rgba(180,0,0,0.35)",
                background: "rgba(220,38,38,0.12)", cursor: "pointer", fontSize: 15,
                color: "#dc2626", display: "flex", alignItems: "center", justifyContent: "center",
                lineHeight: 1, transition: "all 0.18s",
              }} onMouseEnter={e => { e.currentTarget.style.background="rgba(220,38,38,0.85)"; e.currentTarget.style.color="#fff"; }}
                 onMouseLeave={e => { e.currentTarget.style.background="rgba(220,38,38,0.12)"; e.currentTarget.style.color="#dc2626"; }}>✕</button>
            </div>
          </div>
          {/* Deco row */}
          <div style={{ display: "flex", gap: 4, marginTop: 10, opacity: 0.6 }}>
            {theme.deco.map((d, i) => <span key={i} style={{ fontSize: 14 }}>{d}</span>)}
          </div>
        </div>
      </div>

      {/* Calendar grid */}
      <div style={{ background: theme.card, padding: "16px 20px 20px" }}>
        {/* Day headers */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 4, marginBottom: 8 }}>
          {DAYS.map(d => (
            <div key={d} style={{ textAlign: "center", fontWeight: 800, fontSize: 11,
              color: theme.accent, textTransform: "uppercase", letterSpacing: 0.5, padding: "4px 0" }}>
              {d}
            </div>
          ))}
        </div>

        {/* Day cells */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 4 }}>
          {cells.map((day, i) => {
            if (!day) return <div key={`e${i}`} />;
            const isToday = isCurrentMonth && day === today.getDate();
            const key = `${year}-${month}-${day}`;
            const dayEvents = events[key] || [];
            const hasEvents = dayEvents.length > 0;

            return (
              <div key={day} title={hasEvents ? dayEvents.map(e => e.name).join(", ") : ""}
                style={{
                  borderRadius: 10, padding: "6px 4px", textAlign: "center",
                  position: "relative", cursor: hasEvents ? "pointer" : "default",
                  background: isToday
                    ? theme.accent
                    : hasEvents
                      ? theme.soft
                      : "transparent",
                  border: isToday ? `2px solid ${theme.highlight}`
                    : hasEvents ? `2px solid ${theme.border}`
                    : "2px solid transparent",
                  boxShadow: isToday ? `0 4px 12px ${theme.accent}55` : "none",
                  transition: "transform 0.15s",
                  minHeight: 44,
                }}>
                <span style={{
                  fontWeight: isToday ? 900 : 600,
                  fontSize: 14,
                  color: isToday ? "#fff" : theme.text,
                  display: "block",
                }}>
                  {day}
                </span>
                {isToday && (
                  <div style={{ position: "absolute", bottom: 2, left: 0, right: 0,
                    display: "flex", justifyContent: "center" }}>
                    <PawPrint size={10} color="rgba(255,255,255,0.8)" />
                  </div>
                )}
                {hasEvents && !isToday && (
                  <div style={{ display: "flex", justifyContent: "center", gap: 2, flexWrap: "wrap", marginTop: 2 }}>
                    {dayEvents.slice(0, 3).map((ev, ei) => (
                      <div key={ei} style={{
                        width: 6, height: 6, borderRadius: "50%", background: ev.color,
                      }} />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Legend with hover tooltips */}
        {Object.keys(pet.vaccineHistory || {}).length > 0 && (
          <div style={{ marginTop: 16, paddingTop: 12, borderTop: `1px solid ${theme.border}55` }}>
            <p style={{ margin: "0 0 8px", fontSize: 11, fontWeight: 700, color: theme.accent, textTransform: "uppercase", letterSpacing: 1 }}>
              Upcoming reminders — hover for 2-year schedule
            </p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {VACCINE_SCHEDULES[pet.type].map(v => {
                const lastDateStr = (pet.vaccineHistory || {})[v.name];
                if (!lastDateStr) return null;
                const now = new Date(); now.setHours(0,0,0,0);
                const cutoff = new Date(now); cutoff.setFullYear(cutoff.getFullYear() + 2);
                const upcoming = [];
                const cursor = new Date(lastDateStr);
                cursor.setMonth(cursor.getMonth() + v.intervalMonths);
                while (cursor < now) cursor.setMonth(cursor.getMonth() + v.intervalMonths);
                const rolling = new Date(cursor);
                while (rolling <= cutoff) {
                  upcoming.push(new Date(rolling));
                  rolling.setMonth(rolling.getMonth() + v.intervalMonths);
                }
                return <ReminderPill key={v.name} vaccine={v} upcoming={upcoming} theme={theme} />;
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
const navBtn = (theme) => ({
  width: 32, height: 32, borderRadius: 8, border: `1.5px solid ${theme.border}`,
  background: "rgba(255,255,255,0.5)", cursor: "pointer", fontSize: 18, fontWeight: 900,
  color: theme.text, display: "flex", alignItems: "center", justifyContent: "center",
  lineHeight: 1,
});

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null);
  const [showAddPet, setShowAddPet] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);

  // On mount, check for active session
  useEffect(() => {
    const session = localStorage.getItem("furrylife_session");
    if (session) {
      const { email } = JSON.parse(session);
      const raw = localStorage.getItem(`furrylife_user_${email}`);
      if (raw) setUser(JSON.parse(raw));
    }
  }, []);

  const handleAuth = (u) => {
    setUser(u);
    localStorage.setItem("furrylife_session", JSON.stringify({ email: u.email }));
  };

  const handleLogout = () => {
    localStorage.removeItem("furrylife_session");
    setUser(null);
  };

  const handleRemovePet = (petId) => {
    const updated = { ...user, pets: (user.pets || []).filter(p => p.id !== petId) };
    setUser(updated);
    localStorage.setItem(`furrylife_user_${user.email}`, JSON.stringify(updated));
  };

  const isPremium = user?.premium === true;
  const petCount = (user?.pets || []).length;
  const canAddPet = isPremium || petCount < FREE_PET_LIMIT;

  const handleAddPet = (pet) => {
    const updated = { ...user, pets: [...(user.pets || []), pet] };
    setUser(updated);
    localStorage.setItem(`furrylife_user_${user.email}`, JSON.stringify(updated));
  };

  const handleUpgrade = () => {
    const updated = { ...user, premium: true };
    setUser(updated);
    localStorage.setItem(`furrylife_user_${user.email}`, JSON.stringify(updated));
    setShowUpgrade(false);
  };

  const handleAddPetClick = () => {
    if (!canAddPet) { setShowUpgrade(true); return; }
    setShowAddPet(true);
  };

  const fonts = (
    <>
      <style>{`
        @keyframes fadeUp { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes shimmer { 0%,100% { opacity:.6 } 50% { opacity:1 } }
        * { box-sizing: border-box; }
        input::placeholder { color: rgba(255,255,255,0.35); }
      `}</style>
      <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=Cinzel:wght@400;600;700;900&family=Jost:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,700;0,900;1,700&display=swap" rel="stylesheet" />
    </>
  );

  if (!user) return <>{fonts}<SignIn onAuth={handleAuth} /></>;

  return (
    <>
      {fonts}
      <div style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%)",
        fontFamily: "'Jost', sans-serif",
        padding: "0 0 60px",
      }}>
        {/* Top bar */}
        <div style={{
          display: "flex", justifyContent: "space-between", alignItems: "center",
          padding: "16px 32px", borderBottom: "1px solid rgba(255,255,255,0.08)",
          background: "rgba(255,255,255,0.04)", backdropFilter: "blur(10px)",
          position: "sticky", top: 0, zIndex: 50,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 26 }}>🐾</span>
            <div>
              <h1 style={{ margin: 0, color: "#fff", fontSize: 20, fontWeight: 900,
                fontFamily: "'Cinzel', serif", letterSpacing: 1 }}>The Furry Life</h1>
              <p style={{ margin: 0, color: "#93c5fd", fontSize: 11 }}>
                Welcome back, <strong>{user.name}</strong> 👋
              </p>
            </div>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            {!isPremium && (
              <div style={{ display: "flex", alignItems: "center", gap: 6,
                background: "rgba(245,158,11,0.12)", border: "1px solid rgba(245,158,11,0.3)",
                borderRadius: 10, padding: "6px 12px", cursor: "pointer" }}
                onClick={() => setShowUpgrade(true)}>
                <span style={{ fontSize: 12 }}>⭐</span>
                <span style={{ color: "#f59e0b", fontSize: 12, fontWeight: 700 }}>
                  {petCount}/{FREE_PET_LIMIT} pets
                </span>
                <span style={{ color: "#78350f", fontSize: 11, background: "#f59e0b",
                  borderRadius: 6, padding: "1px 6px", fontWeight: 700 }}>FREE</span>
              </div>
            )}
            {isPremium && (
              <div style={{ display: "flex", alignItems: "center", gap: 6,
                background: "rgba(139,92,246,0.12)", border: "1px solid rgba(139,92,246,0.3)",
                borderRadius: 10, padding: "6px 12px" }}>
                <span style={{ fontSize: 12 }}>✨</span>
                <span style={{ color: "#a78bfa", fontSize: 12, fontWeight: 700 }}>PREMIUM</span>
              </div>
            )}
            <button onClick={handleAddPetClick} style={{
              padding: "8px 18px", borderRadius: 10, border: "none",
              background: canAddPet ? "linear-gradient(135deg, #3b82f6, #8b5cf6)" : "linear-gradient(135deg, #f59e0b, #d97706)",
              color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: 13,
              fontFamily: "'Jost', sans-serif",
            }}>{canAddPet ? "+ Add Pet" : "🔒 Upgrade"}</button>
            <button onClick={handleLogout} style={{
              padding: "8px 14px", borderRadius: 10,
              border: "1px solid rgba(255,255,255,0.18)",
              background: "transparent", color: "#94a3b8", fontWeight: 500,
              cursor: "pointer", fontSize: 13, fontFamily: "'Jost', sans-serif",
              transition: "all 0.2s",
            }}
              onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,255,255,0.08)"; e.currentTarget.style.color = "#fff"; }}
              onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "#94a3b8"; }}
            >Sign out</button>
          </div>
        </div>

        {/* Content */}
        <div style={{ padding: "32px 32px 0", maxWidth: 1200, margin: "0 auto" }}>
          {(!user.pets || user.pets.length === 0) ? (
            <div style={{ textAlign: "center", paddingTop: 80, animation: "fadeIn 0.5s ease" }}>
              <div style={{ fontSize: 72, marginBottom: 16 }}>🐾</div>
              <h2 style={{ color: "#fff", fontWeight: 700, fontSize: 28, margin: "0 0 8px", fontFamily: "'Cinzel', serif" }}>
                No companions yet
              </h2>
              <p style={{ color: "#94a3b8", marginBottom: 28, fontSize: 16 }}>
                Add your first furry, feathered or scaly friend to get started.
              </p>
              <button onClick={handleAddPetClick} style={{
                padding: "14px 32px", borderRadius: 14, border: "none",
                background: "linear-gradient(135deg, #3b82f6, #8b5cf6)",
                color: "#fff", fontWeight: 700, fontSize: 15, cursor: "pointer",
                fontFamily: "'Cinzel', serif", letterSpacing: 0.5,
              }}>Add Your First Pet 🐾</button>
            </div>
          ) : (
            <>
              {!isPremium && petCount >= FREE_PET_LIMIT && (
                <div onClick={() => setShowUpgrade(true)} style={{
                  marginBottom: 24, padding: "14px 20px", borderRadius: 14,
                  background: "linear-gradient(135deg, rgba(245,158,11,0.12), rgba(217,119,6,0.08))",
                  border: "1px solid rgba(245,158,11,0.3)", cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                  animation: "fadeIn 0.4s ease",
                }}>
                  <div>
                    <p style={{ margin: 0, color: "#f59e0b", fontWeight: 700, fontSize: 14 }}>
                      ⭐ You've reached your free limit of {FREE_PET_LIMIT} pets
                    </p>
                    <p style={{ margin: "2px 0 0", color: "#94a3b8", fontSize: 12 }}>
                      Upgrade to Premium for unlimited companions — only ${PREMIUM_PRICE}/mo
                    </p>
                  </div>
                  <div style={{
                    padding: "8px 18px", borderRadius: 10, whiteSpace: "nowrap",
                    background: "linear-gradient(135deg, #f59e0b, #d97706)",
                    color: "#fff", fontWeight: 700, fontSize: 13, fontFamily: "'Cinzel', serif",
                  }}>Upgrade ✨</div>
                </div>
              )}
              <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(360px, 1fr))",
                gap: 28,
              }}>
                {user.pets.map(pet => (
                  <PetCalendar key={pet.id} pet={pet} onRemove={handleRemovePet} />
                ))}
              </div>
            </>
          )}
        </div>

        {showAddPet && (
          <AddPetModal onAdd={handleAddPet} onClose={() => setShowAddPet(false)} />
        )}
        {showUpgrade && (
          <UpgradeModal onClose={() => setShowUpgrade(false)} onUpgrade={handleUpgrade} />
        )}
      </div>
    </>
  );
}
